<?php

namespace Mpdf\Tag;

class Cite extends InlineTag
{


}
