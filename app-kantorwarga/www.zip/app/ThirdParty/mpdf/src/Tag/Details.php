<?php

namespace Mpdf\Tag;

class Details extends BlockTag
{


}
